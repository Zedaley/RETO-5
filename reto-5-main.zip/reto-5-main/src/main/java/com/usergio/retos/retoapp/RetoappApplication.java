package com.usergio.retos.retoapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RetoappApplication {

    public static void main(String[] args) {
        SpringApplication.run(RetoappApplication.class, args);
    }

}
